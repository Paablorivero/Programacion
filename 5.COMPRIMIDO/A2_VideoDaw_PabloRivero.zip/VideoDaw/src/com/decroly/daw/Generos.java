
package com.decroly.daw;

public enum Generos {
    ACCION, COMEDIA, DRAMA, FANTASIA, TERROR, DOCUMENTALES;
    
}

