public class ExcepcionesEmpresa extends Exception{
    public ExcepcionesEmpresa(String mensaje){
        super(mensaje);
    }
}
