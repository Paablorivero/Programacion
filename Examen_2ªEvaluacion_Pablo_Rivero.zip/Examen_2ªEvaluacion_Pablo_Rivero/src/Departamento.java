public enum Departamento {
    INFORMATICA, GESTION, MARKETING
}
