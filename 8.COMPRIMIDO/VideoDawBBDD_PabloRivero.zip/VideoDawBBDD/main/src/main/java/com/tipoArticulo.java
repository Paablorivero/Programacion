package com;

public enum tipoArticulo {
    PELICULA, VIDEOJUEGO;  
}
