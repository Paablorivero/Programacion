package com;

public enum GenerosVideojuego {
    SANDBOX, ESTRATEGIA, SHOOTER, ROL, SIMULACION, PUZZLE; 
}